@echo off
echo Instalando Flask...
python -m pip install flask
echo.
echo Flask instalado!
pause